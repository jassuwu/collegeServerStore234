// 20PW14
// Two-fer or 2-fer

function get_str(name) {

    return `One for ${name || 'you'}, one for me.`;
}

console.log(get_str('yo'));