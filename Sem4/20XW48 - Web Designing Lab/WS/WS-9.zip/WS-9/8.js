// 20PW14
// Resistor resistance value

const COLORS = ['black', 'brown', 'red', 'orange', 'yellow', 'green', 'blue', 'violet', 'grey', 'white'];
function colorCode(color) {
    return COLORS.indexOf(color);
};

console.log(colorCode('green'));