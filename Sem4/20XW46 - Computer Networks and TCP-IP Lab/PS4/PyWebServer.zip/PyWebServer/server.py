import socket

s = socket.socket()
host = socket.gethostname()
s.bind((host, 8899))

s.listen(1)
print(f'[SERVER] LISTENING')
while True:
    c, addr = s.accept()
    print(c)
    try:
        message = c.recv(1024)
        filename = message.split()[1]
        print(filename)
        filename = filename.decode().strip('/')
        filename = filename.encode()
        print(filename)

        f = open(filename)
        outputdata = f.read()
        c.send('\nHTTP/1.1 200 OK\n\n'.encode())
        for i in range(0, len(outputdata)):
            c.send(outputdata[i].encode())
        c.send("\r\n".encode())
        c.close()
    except IOError:
        print('FILE NOT FOUND')
        f = open('404.html')
        outputdata = f.read()
        print(outputdata)
        c.send("\nHTTP/1.1 404 Not Found\n\n".encode())
        for i in range(0, len(outputdata)):
            c.send(outputdata[i].encode())
        c.send("\r\n".encode())
        c.close()

s.close()